const createError = require('http-errors')
const dotenv = require("dotenv");
const express = require("express");
const http = require("http");
const logger = require("morgan");
const path = require("path");
const routerFile = require("./routes/index");
const { auth } = require("express-openid-connect");

dotenv.load();

const app = express();

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

app.use(logger("dev"));
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());

const port = process.env.PORT || 3000;

const config = {
  authRequired: false,
  auth0Logout: true,
  baseURL: `http://localhost:${port}`,
};

app.use(auth(config));


app.use(function (req: any, res: any, next: any) {
  res.locals.user = req.oidc.user;
  next();
});

app.use("/", routerFile);

//====MANEJO DE ERRORES====//
//====NO ENCONTRADO====//
app.use(function (req: any, res: any, next: any) {
  const err = new createError(404, "No Encontrado");
  next(err);
});

app.use(function (err: any, req: any, res: any, next: any) {
  res.status(err.status || 500);
  res.render("error", {
    message: err.message,
    error: process.env.NODE_ENV !== "production" ? err : {},
  });
});

http.createServer(app).listen(port, () => {
  console.log(`Listening on ${config.baseURL}`);
});
