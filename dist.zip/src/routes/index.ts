
const router = require("express").Router();
const { requiresAuth } = require("express-openid-connect");
const axios = require("axios");

router.get("/", function (req: any, res: any, next: any) {
  res.render("index", {
    title: "Auth0 Webapp sample Nodejs",
    isAuthenticated: req.oidc.isAuthenticated(),
  });
});

router.get(
  "/profile",
  requiresAuth(),
  function (req: any, res: any, next: any) {
    res.render("profile", {
      userProfile: JSON.stringify(req.oidc.user, null, 2),
      title: "Perfil Pagina",
    });
  }
);

router.get(
  "/starwar",
  requiresAuth(),
  async (req: any, res: any, next: any) => {
    try {
      const { data: { results: starwarsPeople } } = await axios.get(
        "https://swapi.dev/api/people/"
      );

      res.render("startwar", {
        title: "Star Wars Characters", // More descriptive title
        starwarsPeople, // Use destructured variable for clarity
        error: "", // Initialize error to null for success indication
      });

    } catch (error) {
      console.error(error); // Log the error for debugging
      res.render("startwar", {
        title: "Star Wars Characters", // Maintain consistent title
        starwarsPeople: [], // Set empty array for error handling
        error: "Failed to retrieve Star Wars characters", // Informative error message
      });
    }
  }
);

module.exports = router;
